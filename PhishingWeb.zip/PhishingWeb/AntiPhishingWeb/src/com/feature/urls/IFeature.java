package com.feature.urls;

public interface IFeature<T, S> {
	public T extractFeature(S s);
}
